# Google Cloud Text-to-Speech / PHP Example

This is a simple example script I wrote for an article on my personal blog, [FrancescoCodes](http://francesco.codes).

I used it to make a test of the new text-to-speech API, based on WaveNet.

* More info about Google Cloud TTS [on this page](https://cloud.google.com/text-to-speech/).
* Article paragraph from [Cointelegraph](https://cointelegraph.com/news/cisco-developing-confidential-communications-via-blockchain-in-patent-filing).
